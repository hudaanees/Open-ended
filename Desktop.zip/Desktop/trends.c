/*#include <stdio.h>
#include <stdlib.h>
#include <jansson.h>
#include <math.h>

// Structure to represent a temperature reading
typedef struct {
    double temperature;
} TemperatureReading;

// Function to calculate the mean of an array of values
double calculateMean(const double *values, size_t size) {
    double sum = 0.0;
    for (size_t i = 0; i < size; ++i) {
        sum += values[i];
    }
    return sum / size;
}

// Function to calculate the standard deviation of an array of values
double calculateStandardDeviation(const double *values, size_t size, double mean) {
    double sumSquaredDiff = 0.0;
    for (size_t i = 0; i < size; ++i) {
        double diff = values[i] - mean;
        sumSquaredDiff += diff * diff;
    }
    return sqrt(sumSquaredDiff / size);
}

// Function to read temperature data from a file
size_t readTemperatureDataFromFile(const char *filename, TemperatureReading **readings) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        fprintf(stderr, "Failed to open file %s for reading\n", filename);
        exit(EXIT_FAILURE);
    }

    size_t size = 0;
    double temperature;

    // Count the number of lines in the file
    while (fscanf(file, "%lf", &temperature) == 1) {
        size++;
    }

    // Allocate memory for readings
    *readings = (TemperatureReading *)malloc(size * sizeof(TemperatureReading));
    if (*readings == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }

    // Rewind the file and read temperature data
    rewind(file);
    for (size_t i = 0; i < size; ++i) {
        fscanf(file, "%lf", &(*readings)[i].temperature);
    }

    fclose(file);

    return size;
}

// Function to identify anomalies and trends in temperature data
void analyzeTemperatureData(const TemperatureReading *readings, size_t size) {
    // Calculate mean and standard deviation
    double *temperatureValues = (double *)malloc(size * sizeof(double));
    for (size_t i = 0; i < size; ++i) {
        temperatureValues[i] = readings[i].temperature;
    }

    double mean = calculateMean(temperatureValues, size);
    double stdDev = calculateStandardDeviation(temperatureValues, size, mean);

    // Set a threshold for anomaly detection (adjust as needed)
    double anomalyThreshold = mean + 3.0 * stdDev;

    // Identify anomalies and trends
    printf("Anomalies:\n");
    printf("Trends:\n");
    for (size_t i = 0; i < size; ++i) {
        if (readings[i].temperature > anomalyThreshold) {
            printf("Anomaly at Reading %zu: %.2f°C\n", i + 1, readings[i].temperature);
        }

        // Basic trend analysis (comparing consecutive readings)
        if (i > 0) {
            double temperatureChange = readings[i].temperature - readings[i - 1].temperature;
            if (temperatureChange > 0) {
                printf("Increasing trend between Reading %zu and %zu: %.2f°C\n", i, i + 1, temperatureChange);
            } else if (temperatureChange < 0) {
                printf("Decreasing trend between Reading %zu and %zu: %.2f°C\n", i, i + 1, temperatureChange);
            }
        }
    }

    free(temperatureValues);
}

int main(void) {
    // Replace "temperature_data.txt" with the actual filename or path
    const char *filename = "processoutput.txt";

    // Read temperature data from the file
    TemperatureReading *temperatureData;
    size_t dataSize = readTemperatureDataFromFile(filename, &temperatureData);

    // Analyze temperature data for anomalies and trends
    analyzeTemperatureData(temperatureData, dataSize);

    // Free allocated memory
    free(temperatureData);

    return 0;
}
*/
#include <stdio.h>
#include <stdlib.h>
#include <jansson.h>
#include <math.h>

// Structure to represent a temperature reading
typedef struct {
    double temperature;
} TemperatureReading;

// Function to calculate the mean of an array of values
double calculateMean(const double *values, size_t size) {
    double sum = 0.0;
    for (size_t i = 0; i < size; ++i) {
        sum += values[i];
    }
    return sum / size;
}

// Function to calculate the standard deviation of an array of values
double calculateStandardDeviation(const double *values, size_t size, double mean) {
    double sumSquaredDiff = 0.0;
    for (size_t i = 0; i < size; ++i) {
        double diff = values[i] - mean;
        sumSquaredDiff += diff * diff;
    }
    return sqrt(sumSquaredDiff / size);
}

// Function to identify anomalies in temperature data
void identifyAnomalies(const TemperatureReading *readings, size_t size) {
    // Calculate mean and standard deviation
    double *temperatureValues = (double *)malloc(size * sizeof(double));
    for (size_t i = 0; i < size; ++i) {
        temperatureValues[i] = readings[i].temperature;
    }

    double mean = calculateMean(temperatureValues, size);
    double stdDev = calculateStandardDeviation(temperatureValues, size, mean);

    // Set a threshold for anomaly detection (adjust as needed)
    double anomalyThreshold = mean + 3.0 * stdDev;
    printf("mean %f",anomalyThreshold);

    // Identify anomalies
    printf("Anomalies:\n");
    for (size_t i = 0; i < size; ++i) {
        if (readings[i].temperature > anomalyThreshold) {
            printf("Reading %zu: %.2f°C\n", i + 1, readings[i].temperature);
        }
    }

    free(temperatureValues);
}

int main(void) {
    // Assuming you have a dataset of temperature readings
    TemperatureReading temperatureData[] = {
        {20.0},
        {21.0},
        {22.0},
        {23.0},
        {100.0},  // Anomaly
        {21.0},
        {22.0},
        {23.0},
        {20.0},
        {21.0}
    };

    size_t dataSize = sizeof(temperatureData) / sizeof(temperatureData[0]);

    // Identify anomalies in the temperature data
    identifyAnomalies(temperatureData, dataSize);

    return 0;
}
