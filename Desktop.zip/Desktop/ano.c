#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jansson.h>

// Structure to represent environmental data
typedef struct {
    char timestamp[30];
    char city_name[30];
    double longitude;
    double latitude;
    double temperature;
    int humidity;
    double pressure;
    double visibility;
    double wind_speed;
} EnvironmentalData;

// Function to calculate the average temperature
double calculateAverageTemperature(const EnvironmentalData *data, size_t size) {
    double totalTemperature = 0.0;

    for (size_t i = 0; i < size; ++i) {
        totalTemperature += data[i].temperature;
    }

    return totalTemperature / size;
}

int main(void) {
    // Replace "environmental_data.txt" with the actual filename or path
    const char *filename = "processoutput.txt";

    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        fprintf(stderr, "Failed to open file %s for reading\n", filename);
        exit(EXIT_FAILURE);
    }

    // Read the data from the file
    size_t dataSize = 0;
    size_t dataCapacity = 10; // Initial capacity, can be adjusted
    EnvironmentalData *environmentalData = (EnvironmentalData *)malloc(dataCapacity * sizeof(EnvironmentalData));

    if (environmentalData == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    while (fscanf(file, "Timestamp: %29s City Name: %29s Longitude: %lf Latitude: %lf Temperature: %lf°C Humidity: %d%% Pressure: %lf hPa Visibility: %lf meters Wind Speed: %lf m/s\n",
                  environmentalData[dataSize].timestamp,
                  environmentalData[dataSize].city_name,
                  &environmentalData[dataSize].longitude,
                  &environmentalData[dataSize].latitude,
                  &environmentalData[dataSize].temperature,
                  &environmentalData[dataSize].humidity,
                  &environmentalData[dataSize].pressure,
                  &environmentalData[dataSize].visibility,
                  &environmentalData[dataSize].wind_speed) == 9) {
        dataSize++;

        if (dataSize == dataCapacity) {
            // Resize the array if needed
            dataCapacity *= 2;
            environmentalData = (EnvironmentalData *)realloc(environmentalData, dataCapacity * sizeof(EnvironmentalData));

            if (environmentalData == NULL) {
                fprintf(stderr, "Memory reallocation failed\n");
                fclose(file);
                exit(EXIT_FAILURE);
            }
        }
    }

    fclose(file);

    // Calculate the average temperature
    double averageTemperature = calculateAverageTemperature(environmentalData, dataSize);

    // Print the average temperature
    printf("Average Temperature: %.2f°C\n", averageTemperature);

    // Print the last temperature value
    if (dataSize > 0) {
        printf("Last Temperature: %.2f°C\n", environmentalData[dataSize - 1].temperature);
    } else {
        printf("No data available\n");
    }

    // Free allocated memory
    free(environmentalData);

    return 0;
}
