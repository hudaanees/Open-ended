#include <stdio.h>

int main(void) {
    // Open the file for reading
    FILE *file = fopen("processoutput.txt", "r");
    if (file == NULL) {
        fprintf(stderr, "Failed to open file for reading\n");
        return 1;
    }

    // Variables to store temperature and wind speed
    double temperature = 0.0, windSpeed = 0.0;

    // Loop through each line in the file
    char line[256];
    while (fgets(line, sizeof(line), file) != NULL) {
        // Check if the line contains Temperature and Wind Speed information
        if (sscanf(line, "Temperature: %lf°C", &temperature) == 1) {
            // Temperature information found
        } else if (sscanf(line, "Wind Speed: %lf m/s", &windSpeed) == 1) {
            // Wind Speed information found
        }
    }

    // Close the file
    fclose(file);

    // Print the extracted values
    printf("Temperature: %.2f°C\n", temperature);
    printf("Wind Speed: %.2f m/s\n", windSpeed);

    return 0;
}
