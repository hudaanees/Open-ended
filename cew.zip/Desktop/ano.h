#include <stdio.h>
#include <stdlib.h>

// Structure to represent temperature data
typedef struct {
    char timestamp[50];
    char city_name[50];
    double temperature;
    double wind_speed;
} TemperatureData;

// Function to detect anomalies in temperature
void detectAnomalies(double temperature,double windSpeed ,FILE *outputFile) {
    printf("in function");


        // Assume anomaly if temperature is above a certain threshold (adjust as needed)
        if (temperature > 310.0) {
            //printf("%f",data[i].temperature);
            //fprintf(outputFile, "Anomaly Detected:\nTimestamp: %s\nCity Name: %s\nTemperature: %.2f°C\nWind Speed: %.2f m/s\n\n",
              // data[i].timestamp, data[i].city_name, data[i].temperature, data[i].wind_speed);
            // fprintf(outputFile,"%.2f°C","%s",temperature,"Africa") ;
            fprintf(outputFile, "%.2f°C %s", temperature, "Africa");

        }
        if (windSpeed > 2.50) {
            //printf("%f",data[i].temperature);
            //fprintf(outputFile, "Anomaly Detected:\nTimestamp: %s\nCity Name: %s\nTemperature: %.2f°C\nWind Speed: %.2f m/s\n\n",
              // data[i].timestamp, data[i].city_name, data[i].temperature, data[i].wind_speed);
            // fprintf(outputFile,"%.2f°C","%s",temperature,"Africa") ;
            fprintf(outputFile, "%.2fm/s", windSpeed, "Africa");

        }
    }


int main(void) {
     FILE *file = fopen("processoutput.txt", "r");
    if (file == NULL) {
        fprintf(stderr, "Failed to open file for reading\n");
        return 1;
    }

    // Variables to store temperature and wind speed
    double temperature = 0.0, windSpeed = 0.0;

    // Loop through each line in the file
    char line[256];
    while (fgets(line, sizeof(line), file) != NULL) {
        // Check if the line contains Temperature and Wind Speed information
        if (sscanf(line, "Temperature: %lf°C", &temperature) == 1) {
            // Temperature information found
        } else if (sscanf(line, "Wind Speed: %lf m/s", &windSpeed) == 1) {
            // Wind Speed information found
        }
    }

    // Close the file
    fclose(file);

    // Open a file for writing anomalies
    FILE *outputFile = fopen("anomalies.txt", "w");
    if (outputFile == NULL) {
        fprintf(stderr, "Failed to open file for writing\n");
        return EXIT_FAILURE;
    }

    // Check for anomalies and save to the output file
    detectAnomalies(temperature,windSpeed, outputFile);

    // Close the output file
    fclose(outputFile);


    return EXIT_SUCCESS;
}
